tableGroupTree
====
This is a dynamic table that can interact.
----
Function:
----
When user drags the header of the table to the filter area:
1. the data will automatically groups and displays different values under that field.
1. this binds filters for different fields of the table.

Steps:
----
1. Create two different areas, one for the header of the table, and one for the container of the dragging elements.
2. Achieve the head of table sort function. User can drag the corresponding element to the position who want.







